package gcu.backend.axiosex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxiosexApplicationTests {

	@Test
	void contextLoads() {
	}

}
